﻿using System;

namespace ReadUserInput
{
    class Program
    {
        static void Main(string[] args)
        {
            int a;

            Console.WriteLine("Enter any value:");
            a = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine(a);
        }
    }
}
