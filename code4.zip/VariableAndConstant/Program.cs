﻿using System;

namespace VariableAndConstant
{
    class Program
    {
        static void Main(string[] args)
        {
            const int a = 10;

            //a = 50; // error

            Console.WriteLine(a);
        }
    }
}
