﻿using System;

namespace TypeConversion_2
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 34;
            float f = 54.005f;
            double d = 235.7658;
            bool state = true;

            Console.WriteLine(a.ToString());
            Console.WriteLine(f.ToString());
            Console.WriteLine(d.ToString());
            Console.WriteLine(state.ToString());
        }
    }
}
