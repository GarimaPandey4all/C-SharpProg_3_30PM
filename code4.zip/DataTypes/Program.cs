﻿using System;

namespace DataTypes
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 10;
            float b = 24.57f;
            double c = 45.68;
            char ch = 'F';
            string name = "Brain";
            bool state = true;

            /*
            Console.WriteLine(a);
            Console.WriteLine(b);
            Console.WriteLine(c);
            Console.WriteLine(ch);
            Console.WriteLine(name);
            Console.WriteLine(state);
            */

            Console.Write("{0}  {1}  {2}  {3}  {4}  {5}", a, b, c, ch, name, state);
        }
    }
}
