﻿using System;

namespace TypeConversion
{
    class Program
    {
        static void Main(string[] args)
        {
            double d = 345.67; // double - 8 bytes  || 1 byte = 8 bits || double - 64 bits
            int a; // int - 4 bytes || int - 32 bits

            //cast double to int - Explicitly
            a = (int)d;
            Console.WriteLine(a);
        }
    }
}
