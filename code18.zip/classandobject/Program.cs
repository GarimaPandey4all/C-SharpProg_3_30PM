﻿using System;

namespace classandobject
{
    class Human
    {
        string name = "Krrish"; // field or data member

        static void Main(string[] args)
        {
            Human obj = new Human(); // object creation
            Console.WriteLine(obj.name);
        }
    }
}
