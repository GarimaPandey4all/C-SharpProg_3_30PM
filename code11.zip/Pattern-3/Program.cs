﻿using System;

namespace Pattern_3
{
    class Program
    {
        static void Main(string[] args)
        {
            for(int i = 5; i >= 1; i--)
            {
                for(int j = i; j >= 1; j--)
                {
                    //Console.Write(i);
                    //Console.Write("*");
                    Console.Write(j);
                }
                Console.WriteLine();
            }
        }
    }
}
