﻿using System;

namespace Pattern_2
{
    class Program
    {
        static void Main(string[] args)
        {
            for(int i = 1; i <= 5; i++)
            {
                for(int j = 1; j <= i; j++)
                {
                    //Console.Write("*");
                    //Console.Write(j);
                    Console.Write(i);
                }
                Console.WriteLine();
            }
        }
    }
}
