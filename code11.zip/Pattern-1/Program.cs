﻿using System;

namespace Pattern_1
{
    class Program
    {
        static void Main(string[] args)
        {
            for(int i = 1; i <= 5; i++) // rows
            {
                for(int j = 1; j <= 5; j++) // columns
                {
                    //Console.Write("*");
                    //Console.Write(j);
                    Console.Write(i);
                }
                Console.WriteLine();
            }
        }
    }
}

