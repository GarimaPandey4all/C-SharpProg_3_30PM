﻿using System;

namespace FactorialNumber
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter any number:");
            int n = Convert.ToInt32(Console.ReadLine());

            int fact = 1;

            for(int i = 1; i <= n; i++)
            {
                fact *= i;  // fact = fact * i;
            }

            Console.WriteLine("Factorial of a number {0} is {1}", n, fact);
        }
    }
}
