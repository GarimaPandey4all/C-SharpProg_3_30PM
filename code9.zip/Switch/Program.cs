﻿using System;

namespace Switch
{
    class Program
    {
        static void Main(string[] args)
        {
            //switch - Menu driven program
            
            Console.WriteLine("Press 1. Even-Odd");
            Console.WriteLine("Press 2. X-OR");
            Console.WriteLine("Press 3. Addition");
            Console.WriteLine("Enter your choice:");
            int choice = Convert.ToInt32(Console.ReadLine());

            switch(choice)
            {
                case 1:   

                Console.WriteLine("Enter any number:");
                int number = Convert.ToInt32(Console.ReadLine());

                string msg = ((number % 2) == 0) ? "Number is Even" : "Number is Odd";

                Console.WriteLine(msg);

                break;

                case 2:

                Console.WriteLine("Enter any value for a:");
                int a = Convert.ToInt32(Console.ReadLine());
                
                Console.WriteLine("Enter any value for b:");
                int b = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("X-OR is:" +(a ^ b));

                break;

                case 3:

                Console.WriteLine("Enter any value for x:");
                int x = Convert.ToInt32(Console.ReadLine());
                
                Console.WriteLine("Enter any value for y:");
                int y = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Addition is:" +(x + y));

                break;

                default:
                Console.WriteLine("Invalid Choice");

                break;
            }

            //Console.WriteLine("Outside Switch");
        }
    }
}
