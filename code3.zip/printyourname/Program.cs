﻿using System;

namespace printyourname
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Brain Mentors");
        }
    }
}
