﻿using System;

namespace Addition_330PM
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 10, b = 20, c;  // a and b , declare and initialize

            c = a + b; // c - Initialize

            b = 50;
            Console.WriteLine(b);

            Console.WriteLine("Addition is:" +c); // ""--> String // + --> joining/Concatenation
        }
    }
}
