﻿using System;

namespace classesandobjects_3
{
    class Program
    {
        static void Main(string[] args)
        {
            Car Ciaz = new Car();
            Ciaz.setData("Ciaz MS", "Maruti Suzuki", "2020");
            Ciaz.getData();
        }
    }
}
