﻿using System;

namespace classesandobjects_4
{
    class Program
    {
        static void Main(string[] args)
        {
            Car Honda = new Car();
            Honda.model = "H 2020";
            Honda.brand = "Honda 2020";
            Honda.year = "2020";

            Console.WriteLine(Honda.model);
            Console.WriteLine(Honda.brand);
            Console.WriteLine(Honda.year);
        }
    }
}
