namespace classesandobjects_2
{
    public class Car
    {
        public string model = "XUV";
    }
}