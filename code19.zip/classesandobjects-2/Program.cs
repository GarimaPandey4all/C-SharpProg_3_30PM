﻿using System;

namespace classesandobjects_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Car obj = new Car();
            Console.WriteLine(obj.model);
        }
    }
}
