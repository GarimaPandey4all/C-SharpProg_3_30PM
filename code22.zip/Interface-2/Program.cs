﻿using System;

namespace Interface_2
{
    interface IFirstInterface
    {
        void myMethod();
    }

     interface ISecondInterface
    {
        void myOtherMethod();
    }

//Implements multiple interfaces
    class MultipleInterfaces : IFirstInterface, ISecondInterface
    {
        public void myMethod()
        {
            Console.WriteLine("First Interface");
        }

        
        public void myOtherMethod()
        {
            Console.WriteLine("Second Interface");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            MultipleInterfaces obj = new MultipleInterfaces();
            obj.myMethod();
            obj.myOtherMethod();
        }
    }
}
