﻿using System;

namespace Abstraction
{
    //abstract class: it can't be used to create objects but to access it, it must be inherited from the another class.
    abstract class Human
    {
        public abstract void humanBehaviour(); // onle declaration in abstract method

        public void sleep()
        {
            Console.WriteLine("Sleep");
        }  
    }

    class Person : Human
    {
        public override void humanBehaviour()
        {
            Console.WriteLine("Human Behaviour");
        }
    }


    class Program
    {
        static void Main(string[] args)
        {
            //Abstraction: It is the process in which we hiding the 
            //certain details and only showing the essential information to the user.

            /*
                Abstraction achieved by abstract classes or interfaces.
            */

            Person obj = new Person();
            obj.humanBehaviour();
            obj.sleep();
        }
    }
}
