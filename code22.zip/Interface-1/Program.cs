﻿using System;

namespace Interface_1
{
    //Interface is completely similar to abstract classes. It is also used to achieve multiple inheritance.

    interface IHuman
    {
        void humanBehaviour(); // it does not have a body
    }

    // Person implements the IHuman interface
    class Person : IHuman
    {
        public void humanBehaviour()
        {
            Console.WriteLine("Human Behaviour");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Person obj = new Person();
            obj.humanBehaviour();
        }
    }
}
