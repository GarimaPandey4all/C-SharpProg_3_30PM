﻿using System;
using System.IO;

namespace Files_1
{
    class Program
    {
        static void Main(string[] args)
        {
            //Files in C#: Get data from the file and Put Data into the file
            //The file class from the System.IO namespace, allows us to work with files.

            string writeText = "Hi... How are you? Krrish.";
            File.WriteAllText("test.txt", writeText);

            Console.WriteLine("Content inserted successfully in a file");
        }
    }
}
