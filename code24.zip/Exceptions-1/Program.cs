﻿using System;

namespace Exceptions_1
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
                Exceptions: Abnormal condition which occur at runtime errors.

                try and catch

                try: try statement allows you to declare block of code to be tested for errors while it is being executed.

                catch: catch statment allows you to define a block to be executed, if an error occurs in the try block.


                try
                {

                }

                catch(Exception e)
                {

                }
            
            */

            try
            {
                int[] digits = {10, 20, 30, 40, 50};
                Console.WriteLine(digits[6]);

                Console.WriteLine("Try Block");
            }

            catch(Exception e)
            {
                Console.WriteLine(e.Message);

               // Console.WriteLine("Index out of Range");
            }

        }
    }
}
