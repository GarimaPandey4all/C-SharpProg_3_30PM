﻿using System;

namespace Exceptions_3
{

    class Program
    {
        static void findAge(int age)
    {
        if(age < 20)
        {
            throw new ArithmeticException("Not Matched with the age limit");
        }
        else
        {
            Console.WriteLine("Matched with the age limit");
        }
    }

        static void Main(string[] args)
        {
            findAge(13);

            /*
                throw: throw statement allows you to create a custom error.

                Predefined Exception Classes in C#:

                1. Arithmetic Exception
                2. IndexOutofRangeException
                3. FilesNotFoundException            
            */
        }
    }
}
