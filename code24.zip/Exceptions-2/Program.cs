﻿using System;

namespace Exceptions_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enterv any value for a:");
            int a = Convert.ToInt32(Console.ReadLine());
            
            Console.WriteLine("Enterv any value for b:");
            int b = Convert.ToInt32(Console.ReadLine());

            try
            {
                int c = a / b;
                Console.WriteLine("Division is: "+c);
            }

            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }

            //Finally statement lets you execute code, after try and catch blocks.
            finally
            {
                Console.WriteLine("After Try-Catch Blocks");
            }
        }
    }
}
