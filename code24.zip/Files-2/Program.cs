﻿using System;
using System.IO;

namespace Files_2
{
    class Program
    {
        static void Main(string[] args)
        {
            string readText = File.ReadAllText("test.txt");
            Console.WriteLine(readText);
        }
    }
}
