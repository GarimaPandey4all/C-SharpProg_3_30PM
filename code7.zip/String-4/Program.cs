﻿using System;

namespace String_4
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 10;
            int b = 20;

            Console.WriteLine(a + b);

            string x = "10";
            string y = "20";

            Console.WriteLine(x + y);
        }
    }
}
