﻿using System;

namespace If_Else
{
    class Program
    {
        static void Main(string[] args)
        {
            //Decision - Making / Conditional Statements

            Console.WriteLine("Enter any value for a:");
            int a = Convert.ToInt32(Console.ReadLine());
            
            Console.WriteLine("Enter any value for b:");
            int b = Convert.ToInt32(Console.ReadLine());

            if(a > b)
            {
                Console.WriteLine("A is greater than B");
            }
            else
            {
                Console.WriteLine("B is greater than A");
            }
        }
    }
}
