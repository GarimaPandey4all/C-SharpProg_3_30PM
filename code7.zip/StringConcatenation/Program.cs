﻿using System;

namespace StringConcatenation
{
    class Program
    {
        static void Main(string[] args)
        {
            //Concatenation/Joining

            string firstName = "Brain";
            string lastName = "Mentors";

            //string fullName = firstName + lastName;

            string fullName = string.Concat(firstName, lastName);

            Console.WriteLine(fullName);

            //String Interpolation, $

            string name = $"Your Full Name is: {firstName} {lastName}";

            Console.WriteLine(name);

        }
    }
}
