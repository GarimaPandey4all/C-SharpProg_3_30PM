﻿using System;

namespace String_3
{
    class Program
    {
        static void Main(string[] args)
        {
            string name = "Brain Mentors";

            Console.WriteLine(name[2]); // [] - Square Brackets / Subscript Operator // 2 - Index Number (always start from 0)

            Console.WriteLine(name.IndexOf("a"));

            int pos = name.IndexOf("M");

            string subString = name.Substring(pos);

            Console.WriteLine(subString);

            //Double Quote
            Console.WriteLine("This is \"C#\" \nclass."); // backslash '\'- escape character \\ \n - new line

            //Single Quote
            Console.WriteLine("It\'s the\tC#\tclass."); // backslash '\'- escape character \\ \t - tab

            //BackSlash '\'
            Console.WriteLine("It is \\ BackSlash \b!"); // backslash '\'- escape character \\ \b - backspace
        }
    }
}
