﻿using System;

namespace String
{
    class Program
    {
        static void Main(string[] args)
        {
            string name = "Brain Mentors"; // string - Collection of Characters

            Console.WriteLine(name);

            Console.WriteLine("Length of the String is:" +name.Length);

            Console.WriteLine(name.ToUpper());

            Console.WriteLine(name.ToLower());
        }
    }
}
