﻿using System;
using System.Collections;

namespace Collections_3
{
    class Program
    {
        static void Main(string[] args)
        {
            Queue qobj = new Queue();

            qobj.Enqueue('A');
            qobj.Enqueue('B');
            qobj.Enqueue('C');
            qobj.Enqueue('D');
            qobj.Enqueue('E');

            Console.WriteLine("Queue is:");
            foreach(char ch in qobj)
            Console.Write(ch + " ");

            Console.WriteLine();

            qobj.Dequeue();

            Console.WriteLine("Queue is:");
            foreach(char ch in qobj)
            Console.Write(ch + " ");

            Console.WriteLine();
        }
    }
}
