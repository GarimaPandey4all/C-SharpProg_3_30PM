﻿using System;
using System.Collections;

namespace Collections_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Stack sobj = new Stack();

            sobj.Push('A');
            sobj.Push('B');
            sobj.Push('C');
            sobj.Push('D');
            sobj.Push('E');

            Console.WriteLine("Stack is:");
            foreach(char ch in sobj)
            Console.Write(ch + " ");

            Console.WriteLine();

            Console.WriteLine("Top value of stack is: {0}", sobj.Peek());

            sobj.Pop();

            Console.WriteLine("Stack is:");
            foreach(char ch in sobj)
            Console.Write(ch + " ");

            Console.WriteLine();

            

        }
    }
}
