﻿using System;
using System.Collections;

namespace Collections_1
{
    class Program
    {
        static void Main(string[] args)
        {
            //Collections: Classes are specialized classes for data storage and retrieval. These classes support stack, 
            //arrays, linked list, and hashtables.

            //1. Arraylist: It is an alternative to an array, Arraylist resize itself automatically. It allows
            //dynamic memory allocation.

            ArrayList al = new ArrayList();

            Console.WriteLine("Insertion in an Array:");
            al.Add(10);
            al.Add(20);
            al.Add(30);
            al.Add(40);
            al.Add(50);

            Console.WriteLine("Count is: {0}", al.Count);
            Console.WriteLine("Capacity is: {0}", al.Capacity);

            Console.WriteLine("Values in Array are:");
            foreach(int i in al)
            Console.Write(i + " ");
            Console.WriteLine();

            al.Remove(10);
            Console.WriteLine("Values in Array are:");
            foreach(int i in al)
            Console.Write(i + " ");
            Console.WriteLine();

        }
    }
}
