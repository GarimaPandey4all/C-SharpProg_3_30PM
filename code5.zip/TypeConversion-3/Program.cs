﻿using System;

namespace TypeConversion_3
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
                built-in methods:

                Convert.ToBoolean
                Convert.ToDouble
                Convert.ToString
                Convert.ToInt32(int) // int - 4 bytes
                Convert.ToInt64(long) // long int - 8 bytes
            */

            int a = 10;
            double d = 45.78;
            bool state = true;

            Console.WriteLine(Convert.ToString(a));
            Console.WriteLine(Convert.ToDouble(a));
            Console.WriteLine(Convert.ToInt32(d));
            Console.WriteLine(Convert.ToString(state));
        }
    }
}
