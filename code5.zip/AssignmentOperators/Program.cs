﻿using System;

namespace AssignmentOperators
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 10, b = 20;

            int c = a + b;

            Console.WriteLine(c);
        }
    }
}
