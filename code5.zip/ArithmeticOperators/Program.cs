﻿using System;

namespace ArithmeticOperators
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter any value for a:");
            int a = Convert.ToInt32(Console.ReadLine());
            
            Console.WriteLine("Enter any value for b:");
            int b = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Addition is:"+(a+b));
            Console.WriteLine("Subtraction is:"+(a-b));
            Console.WriteLine("Multiplication is:"+(a*b));
            Console.WriteLine("Division is:"+(a/b)); //quotient

            Console.WriteLine("Modulus is:"+(a%b)); //remainder
            
            //Pre or Post Increment : ++

            // a = 5
            Console.WriteLine("Pre-Increment is:"+(++a)); // a = 6
            // a = 6
            Console.WriteLine("Post-Increment is:"+(a++)); // a = 6

            // a = 7

            Console.WriteLine(a);

            //Pre or Post Decrement : --

            // b = 6
            Console.WriteLine("Pre-Decrement is:"+(--b)); // b = 5
            // b = 5
            Console.WriteLine("Post-Decrement is:"+(b--)); // b = 5

            // b = 4

            Console.WriteLine(b);
            
        }

    }
}
