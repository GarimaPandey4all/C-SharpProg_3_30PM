﻿using System;

namespace AssignmentOperators_2
{
    class Program
    {
        static void Main(string[] args)
        {
            int sum;

            Console.WriteLine("Enter any value:");
            sum = Convert.ToInt32(Console.ReadLine());

            //Shorthand
            sum += 10; //sum = sum + 10; // += : Add and Assignment Operator

            Console.WriteLine("Sum is:"+sum);
        }
    }
}
