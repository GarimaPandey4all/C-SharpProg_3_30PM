﻿using System;

namespace Array_4
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] lists = {40, 20, 10, 50, 5};

            Array.Sort(lists);

            foreach(int i in lists)
            {
                Console.WriteLine(i);
            }

            for(int i = lists.Length-1; i >= 0; i--)
            {
                Console.WriteLine(lists[i]);
            }
        }
    }
}
