﻿using System;

namespace Array_2
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] books = {"C#", "C", "Java", "JavaScript"};

            for(int i = 0; i < books.Length; i++)
            {
                Console.WriteLine(books[i]);
            }
        }
    }
}
