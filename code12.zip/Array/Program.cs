﻿using System;

namespace Array
{
    class Program
    {
        static void Main(string[] args)
        {
            //Array: It is a Collection of similar types of Data. It contains multiple values in a single variable.
            //Array: Continuous Memory Alloacation

            int[] numbers = {10, 20, 30, 40, 50, 60, 70, 80, 90}; // Array Declaration & Initialization// [] - Sqaure Brackets/Subscript Operator
            //numbers- size = 5

            Console.WriteLine(numbers[3]);
            Console.WriteLine(numbers[1]);

            Console.WriteLine(numbers.Length);

        }
    }
}
