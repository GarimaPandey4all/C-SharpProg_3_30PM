﻿using System;
using System.Linq;

namespace Array_5
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] lists = {30, 50, 70, 80, 10}; // 30 + 50 + 70 + 80 + 10 = 240

            Console.WriteLine(lists.Sum());
            Console.WriteLine(lists.Min());
            Console.WriteLine(lists.Max());
        }
    }
}
