﻿using System;

namespace Array_3
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] lists = {10, 20, 30, 40, 50, 60, 70, 80, 90, 100};

            foreach(int i in lists)
            {
                Console.WriteLine(i);
            }
        }
    }
}
