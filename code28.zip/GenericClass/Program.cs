﻿using System;

namespace GenericClass
{
    public class MyGeneric<T>
    {
        private T[] array; 

        public MyGeneric(int size)
        {
            array = new T[size];
        }

        public void setItem(int index, T value)
        {
            array[index] = value;
        }

        public T getItem(int index)
        {
            return array[index];
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            //Declare int array

            MyGeneric<int> intArray = new MyGeneric<int>(5);

            //Setting Values
            for(int i = 0; i < 5; i++)
            intArray.setItem(i, i * 5);

            //Accessing values from an array
            for(int i = 0; i < 5; i++)
            Console.Write(intArray.getItem(i) + " ");

            Console.WriteLine();

            //Declare char array

            MyGeneric<char> charArray = new MyGeneric<char>(5);

            //Setting Values
            for(int i = 0; i < 5; i++)
            charArray.setItem(i, (char)(i + 65));

            //Accessing values from an array
            for(int i = 0; i < 5; i++)
            Console.Write(charArray.getItem(i) + " ");

            Console.WriteLine();


        }
    }
}
