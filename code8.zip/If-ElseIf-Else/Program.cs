﻿using System;

namespace If_ElseIf_Else
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter any value for a:");
            int a = Convert.ToInt32(Console.ReadLine());
            
            Console.WriteLine("Enter any value for b:");
            int b = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter any value for c:");
            int c = Convert.ToInt32(Console.ReadLine());

            /*
                a, b, c
                ((a > b) && (a > c))

                (b > c)

                c
            */

                if((a > b) && (a > c))
                {
                    Console.WriteLine("a is greater");
                }
                else if(b > c)
                {
                    Console.WriteLine("b is greater");
                }
                else
                {
                    Console.WriteLine("c is greater");
                }
        }

    }
}
