﻿using System;

namespace Even_Odd
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter any number:");
            int number = Convert.ToInt32(Console.ReadLine());

            int remainder = number % 2;

            if(remainder == 0)
            Console.WriteLine("Number is Even"); 
            else
            Console.WriteLine("Number is Odd");
        }
    }
}
