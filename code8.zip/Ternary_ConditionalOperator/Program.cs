﻿using System;

namespace Ternary_ConditionalOperator
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
                Ternary Operator / Conditional Operator - ? :

                (condition) ? true : false;

                (Expression-1) ? Expression -2 : Expression-3;
            */

            Console.WriteLine("Enter any number:");
            int number = Convert.ToInt32(Console.ReadLine());

            string msg = ((number % 2) == 0) ? "Number is Even" : "Number is Odd";

            Console.WriteLine(msg);
        }
    }
}
