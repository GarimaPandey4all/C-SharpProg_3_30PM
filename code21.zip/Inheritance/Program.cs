﻿using System;

namespace Inheritance
{
    class Program
    {
        static void Main(string[] args)
        {
            //Inheritance: inherit parent class features in child class

            // Parent Class - Base Class, Child Class - Derived Class 

            Car obj = new Car(); // Car Object
            obj.Honk();

            Console.WriteLine(obj.brand);
            Console.WriteLine(obj.modelName);

        }
    }
}
