using System;

namespace Inheritance
{
    public class Vehicle
    {
        public string brand = "Honda";

        public void Honk()
        {
            Console.WriteLine("Pee Pee");
        }
    }
}