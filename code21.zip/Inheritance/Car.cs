namespace Inheritance
{
    public class Car : Vehicle // Inheritance
    {
        public string modelName = "Honda H20";
    }
}