﻿using System;

namespace Polymorphism_1
{
    class Animal
    {
        public virtual void animalSound()
        {
            Console.WriteLine("Animal Sound");
        }
    }

    class Dog : Animal
    {
        public override void animalSound()
        {
            Console.WriteLine("Dog Sound");
        }
    }

    class Cat : Animal
    {
        public override void animalSound()
        {
            Console.WriteLine("Cat Sound");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            /*
                Polymorphism: poly - many ; morphism - forms : many forms

                person: employee, son, father, husband etc
            
            */

            Animal obj1 = new Animal();
            Animal obj2 = new Dog();
            Animal obj3 = new Cat();

            obj1.animalSound();
            obj2.animalSound();
            obj3.animalSound();
        }
    }
}
