namespace Properties
{
    public class Human
    {
        private string name;

        public string Name // property
        {
            set 
            {
                name = value;
            }

            get
            {
                return name;
            }
        }
    }
}