﻿using System;

namespace Properties
{
    class Program
    {
        static void Main(string[] args)
        {
            //Property: it is a combination of a variable and method, it has two methods: get and set.
            Human obj = new Human();
            obj.Name = "Krrish";
            Console.WriteLine(obj.Name);

        }
    }
}
