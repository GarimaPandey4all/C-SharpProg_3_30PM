﻿using System;

namespace Properties_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Human obj = new Human();
            obj.Name = "Krrish";
            Console.WriteLine(obj.Name);
        }
    }
}
