namespace Properties_2
{
    public class Human
    {
        public string Name // property
        {
            set;
            get;            
        }
    }
}