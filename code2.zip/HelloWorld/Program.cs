﻿using System; // namespace

namespace HelloWorld
{
    class Program
    {   /*
        This is comment
        This is comment
        This is comment
        This is comment
        This is comment
        This is comment
    */
        static void Main(string[] args) //main() - Entry point
        {
            //System.Console.WriteLine("Brain Mentors");

            Console.WriteLine("Brain Mentors");
        }
    }
}
