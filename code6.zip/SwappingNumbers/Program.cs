﻿using System;

namespace SwappingNumbers
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter any value for a:");
            int a = Convert.ToInt32(Console.ReadLine());
            
            Console.WriteLine("Enter any value for b:");
            int b = Convert.ToInt32(Console.ReadLine());

            int temp;

            //Swapping Two Numbers by using Third Variable

            Console.WriteLine("Before Swapping the value of a={0} and b={1}:", a, b);

            temp = a;
            a = b;
            b = temp;

            Console.WriteLine("After Swapping the value of a={0} and b={1}:", a, b);
        }
    }
}
