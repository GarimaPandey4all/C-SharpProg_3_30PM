﻿using System;

namespace ComparisonOperaators
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 5, b = 0;

            //Comparison Operators:

            /*
                == : Equal to 
                != : Not Equal to
                > : Greater Than 
                < : Less Than
                >= : Greater Than equal to
                <= : Less Than equal to
            */

            Console.WriteLine(a == b);
            Console.WriteLine(a != b);
            Console.WriteLine(a > b);
            Console.WriteLine(a < b);
            Console.WriteLine(a >= b);
            Console.WriteLine(a <= b);
        }
    }
}
