﻿using System;

namespace BitwiseOperators
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 5, b = 7;

            Console.WriteLine("Bitwise AND Operator:"+(a & b));
            Console.WriteLine("Bitwise OR Operator:"+(a | b));
            Console.WriteLine("Bitwise X-OR Operator:"+(a ^ b));
            Console.WriteLine("Bitwise Left Shift Operator:"+(a << 1));
            Console.WriteLine("Bitwise Right Shift Operator:"+(a >> 1));
        }
    }
}
