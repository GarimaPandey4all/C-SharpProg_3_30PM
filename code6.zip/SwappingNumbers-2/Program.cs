﻿using System;

namespace SwappingNumbers_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter any value for a:");
            int a = Convert.ToInt32(Console.ReadLine());
            
            Console.WriteLine("Enter any value for b:");
            int b = Convert.ToInt32(Console.ReadLine());

            /*
            //First Way: + and - Operators

            // a = 5 , b = 7

            Console.WriteLine("Before Swapping the value of a={0} and b={1}", a, b);

            a = a + b; // a = 5 + 7 = 12
            b = a - b; // b = 12 - 7 = 5
            a = a - b; // a = 12 - 5 = 7

            Console.WriteLine("After Swapping the value of a={0} and b={1}", a, b);
            */

            /*

            //Second Way: * and / Operators

            // a = 5 , b = 7

            Console.WriteLine("Before Swapping the value of a={0} and b={1}", a, b);

            a = a * b; // a = 5 * 7 = 35
            b = a / b; // b = 35 / 7 = 5
            a = a / b; // a = 35 / 5 = 7

            Console.WriteLine("After Swapping the value of a={0} and b={1}", a, b);

            */

            //Third Way: X-OR ^ Operator

            // a = 5 , b = 7

            Console.WriteLine("Before Swapping the value of a={0} and b={1}", a, b);

            a = a ^ b; // a = 5 ^ 7 = 2
            b = a ^ b; // b = 12 ^ 7 = 5
            a = a ^ b; // a = 12 ^ 5 = 7

            Console.WriteLine("After Swapping the value of a={0} and b={1}", a, b);
        }
    }
}
