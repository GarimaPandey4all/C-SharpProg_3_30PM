﻿using System;

namespace LogicalOperators
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 5, b = 0;

            /*
                Logical Operators:

                && : Logical AND Operator
                || : Logical OR Operator
                !  : Logical Not Operator
            */

            Console.WriteLine(a > b && b > a); // true && false = false
            Console.WriteLine(a > b || b > a); // true || false = true 
            Console.WriteLine(!(a > b && b > a)); // !false = true
        }
    }
}
