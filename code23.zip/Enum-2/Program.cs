﻿using System;

namespace Enum_2
{
    class Program
    {
        enum Week
            {
                Monday = 1,
                Tuesday,
                Wednesday,
                Thursday,
                Friday,
                Saturday,
                Sunday
            } 

        static void Main(string[] args)
        {
            int num = (int) Week.Sunday;
            Console.WriteLine(num);
        }
    }
}
