﻿using System;

namespace Enum_1
{
    class Program
    {

         enum Week
            {
                Monday,
                Tuesday,
                Wednesday,
                Thursday,
                Friday,
                Saturday,
                Sunday
            } 

        static void Main(string[] args)
        {
            // Enum : Enumeration: It is used to store of group of constants in a single variable.

           Week today = Week.Sunday;

           Console.WriteLine(today);
            
        }
    }
}
