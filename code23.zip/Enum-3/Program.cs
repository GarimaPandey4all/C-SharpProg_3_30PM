﻿using System;

namespace Enum_3
{
    class Program
    {

        enum Color
        {
            red,
            green,
            blue
        }

        static void Main(string[] args)
        {
            Color color = Color.blue;
            Console.WriteLine(color);
        }
    }
}
