﻿using System;

namespace forLoop
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
            for(int i = 1; i<=10; i++)
            {
                Console.WriteLine(i);
            }
            */

            Console.WriteLine("Enter any number to print the table:");
            int n = Convert.ToInt32(Console.ReadLine());

            for(int i = 1; i <= 10; i++)
            {
                Console.WriteLine("{0} * {1} = {2}", n, i, n * i);
            }    
        }
    }
}
