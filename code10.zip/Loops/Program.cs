﻿using System;

namespace Loops
{
    class Program
    {
        static void Main(string[] args)
        {
            //Loops: Loops is used to execute a block of code definite number of times.

            int i = 1;

            while(i <= 10)
            {
                Console.WriteLine("Hello World");
                i++;
            }
        }
    }
}
