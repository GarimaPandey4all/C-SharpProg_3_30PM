﻿using System;

namespace Do_While_2Loop
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter any number to print the table:");
            int n = Convert.ToInt32(Console.ReadLine());

            int i = 1;

            do
            {
                Console.WriteLine("{0} * {1} = {2}", n, i, n * i);
                i++;
            }while(i <= 10);
        }
    }
}
