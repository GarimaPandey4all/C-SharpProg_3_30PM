﻿using System;
using System.Collections;

namespace Hashtable_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Hashtable obj = new Hashtable();
            
            obj.Add("100", "Rishi");
            obj.Add("101", "Krrish");
            obj.Add("102", "Rahul");
            obj.Add("103", "Nikita");
            obj.Add("104", "Ekta");

            if(obj.ContainsValue("Shivam"))
                Console.WriteLine("He is already in a hashtable");
            else
            obj.Add("105", "Shivam");

            //Get a collection of keys
            ICollection key = obj.Keys;

            foreach(string str in key)
            Console.WriteLine(str + " : " + obj[str]);
        }
    }
}
