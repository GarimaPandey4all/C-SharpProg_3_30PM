﻿using System;
using System.Collections;

namespace Sortedlist_1
{
    class Program
    {
        static void Main(string[] args)
        {
            //SortedList: It is a combination of ArrayList(Access by index value) and Hashtable(Access by key-value pair).
            //It is always access the values in an ascending order.

            SortedList obj = new SortedList();

            obj.Add("100", "Rishi");
            obj.Add("101", "Rahul");
            obj.Add("102", "Krrish");
            obj.Add("103", "Renuka");
            obj.Add("104", "Ekta");

            if(obj.ContainsValue("Shivam"))
            Console.WriteLine("Already Available");
            else
            obj.Add("105", "Shivam");

            ICollection key = obj.Keys;

            foreach(string str in key)
            Console.WriteLine(str + " : " + obj[str]);

        }
    }
}
