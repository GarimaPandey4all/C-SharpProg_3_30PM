﻿using System;

namespace Function_4
{
    class Program
    {
        //4. Function with arguments and with return value

        static int Add(int a, int b)
        {
            return (a + b);
        }

        static void Main(string[] args)
        {
            int result = Add(10, 20);

            Console.WriteLine("Addition is:"+result);
        }
    }
}
