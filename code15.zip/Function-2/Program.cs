﻿using System;

namespace Function_2
{
    class Program
    {
        //2. Function with arguments and without return value

        static void Add(int a, int b) // a, b: function parameters/Formal arguments
        {
            Console.WriteLine("Addition is:"+(a + b));
        }

        static void Main(string[] args)
        {
            Add(10, 20); // 10, 20: Actual Arguments/Function arguments
            Add(30, 40);
            Add(50, 70);
        }
    }
}