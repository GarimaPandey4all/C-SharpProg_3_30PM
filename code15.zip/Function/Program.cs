﻿using System;

namespace Function
{
    class Program
    {
        //Function/Method: It is used to represent the particular task. It provides the reusability, because make once 
        //use many times.

        /*
            Method has four types:

            1. Function without arguments and without return value
            2. Function with arguments and without return value
            3. Function without arguments and with return value
            4. Function with arguments and with return value
        
        */

        //1. Function without arguments and without return value


        // void : Data type , void = null or empty, void in function: return type of function
        static void MyFunction() // Method/Function definition/initialization
        {
            Console.WriteLine("Hello World");
        }

        static void Main(string[] args)
        {
            MyFunction(); // Method/Function Calling
            MyFunction();
            MyFunction();
            MyFunction();
            MyFunction();
        }
    }
}
