﻿using System;

namespace Function_3
{
    class Program
    {
        //3. Function without arguments and with return value

        static int Add()
        {
            int a, b;

            Console.WriteLine("Enter value for a:");
            a = Convert.ToInt32(Console.ReadLine());
            
            Console.WriteLine("Enter value for b:");
            b = Convert.ToInt32(Console.ReadLine());

            return (a + b);
        }

        static void Main(string[] args)
        {
            int result = Add();

            Console.WriteLine("Addition is:"+result);
        }
    }
}
