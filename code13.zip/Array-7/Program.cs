﻿using System;

namespace Array_7
{
    class Program
    {
        static void Main(string[] args)
        {
            string[,] matrix = new string[2,3];

            Console.WriteLine("Enter books in matrix:");
            for(int i = 0; i < 2; i++) // rows
            {
                for(int j = 0; j < 3; j++)
                {
                    matrix[i, j] = Console.ReadLine();
                }
            }

            Console.WriteLine("Books in matrix are:");
            for(int i = 0; i < 2; i++) // rows
            {
                for(int j = 0; j < 3; j++)
                {
                    Console.Write("{0}\t", matrix[i, j]);
                }
                Console.WriteLine();
            }
        }
    }
}
