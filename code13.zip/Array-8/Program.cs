﻿using System;

namespace Array_8
{
    class Program
    {
        static void Main(string[] args)
        {
            int[,] matrix1 = new int[5, 5];
            int[,] matrix2 = new int[5, 5];
            int[,] result = new int[5, 5];

            Console.WriteLine("Enter number of rows:");
            int rows = Convert.ToInt32(Console.ReadLine());
            
            Console.WriteLine("Enter number of columns:");
            int columns = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter values in Matrix-1:");
            for(int i = 0; i < rows; i++)
            {
                for(int j = 0; j < columns; j++)
                {
                    matrix1[i, j] = Convert.ToInt32(Console.ReadLine());
                }
            }

            Console.WriteLine("Enter values in Matrix-2:");
            for(int i = 0; i < rows; i++)
            {
                for(int j = 0; j < columns; j++)
                {
                    matrix2[i, j] = Convert.ToInt32(Console.ReadLine());
                }
            }

            Console.WriteLine("Values in Matrix-1:");
            for(int i = 0; i < rows; i++)
            {
                for(int j = 0; j < columns; j++)
                {
                    Console.Write("{0}\t", matrix1[i, j]);
                }
                Console.WriteLine();
            }

            Console.WriteLine("Values in Matrix-2:");
            for(int i = 0; i < rows; i++)
            {
                for(int j = 0; j < columns; j++)
                {
                    Console.Write("{0}\t", matrix2[i, j]);
                }
                Console.WriteLine();
            }

            for(int i = 0; i < rows; i++)
            {
                for(int j = 0; j < columns; j++)
                {
                    result[i, j] = matrix1[i, j] + matrix2[i, j];
                }
            }

            Console.WriteLine("Addition is:");
            for(int i = 0; i < rows; i++)
            {
                for(int j = 0; j < columns; j++)
                {
                    Console.Write("{0}\t", result[i, j]);
                }
                Console.WriteLine();
            }
        }
    }
}
