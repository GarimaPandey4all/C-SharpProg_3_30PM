﻿using System;

delegate int NumberChanger(int n);

namespace Delegates_2
{
    class Program
    {
        static int num = 10;

        public static int Add(int a)
        {
            num += a;
            return num;
        }

        public static int Mul(int a)
        {
            num *= a;
            return num;
        }

        public static int display()
        {
            return num;
        }
        
        static void Main(string[] args)
        {
            NumberChanger obj;
            NumberChanger obj1 = new NumberChanger(Add);
            NumberChanger obj2 = new NumberChanger(Mul);

            obj = obj1;
            obj += obj2; //obj = obj + obj2;

            //Calling of Multicast
            obj(10);
            Console.WriteLine("Value of number is: "+display());
        }
    }
}
