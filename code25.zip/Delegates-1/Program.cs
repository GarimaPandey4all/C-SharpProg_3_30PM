﻿using System;

//Declaration of Delegate
delegate int NumberChanger(int n);

namespace Delegates_1
{
    class Program
    {
        static int num = 10;

        public static int Add(int a)
        {
            num += a;
            return num;
        }

        public static int Mul(int a)
        {
            num *= a;
            return num;
        }

        public static int display()
        {
            return num;
        }

        static void Main(string[] args)
        {
            /*
                Delegates: Delegates are similar to pointers to functions in C or C++.

                A delegate is a reference/address type variable that holds the reference to a method.
                The reference can be changed at runtime.
                Delegates derived from the System.Delegate class.

                How to declare delegate in a program:
                public delegate int MyDelegate(int i);

                Instantiating Delegate:
                MyDelegate dl = new MyDelegate();

            */

            NumberChanger obj1 = new NumberChanger(Add);
            NumberChanger obj2 = new NumberChanger(Mul);

            obj1(20);
            Console.WriteLine("Addition is: "+display());

            obj2(5);
            Console.WriteLine("Multiplication is: "+display());

        }
    }
}
