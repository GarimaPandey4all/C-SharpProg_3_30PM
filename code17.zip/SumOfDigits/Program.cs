﻿using System;

namespace SumOfDigits
{
    class Program
    {
        static void Main(string[] args)
        {
            int sum = 0;

            Console.WriteLine("Enter any number:");
            int n = Convert.ToInt32(Console.ReadLine());

            //  n = 121 = 121

            while(n > 0)
            {
                int r = n % 10; // 
                sum = sum + r; // 
                n = n / 10; // 
            }

            Console.WriteLine("Sum of Digits is:"+sum);  
        }
    }
}
