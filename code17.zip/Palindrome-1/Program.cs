﻿using System;

namespace Palindrome_1
{
    class Program
    {
        static void Main(string[] args)
        {
            //121 = 121 --> Palindrome Number

            int sum = 0, temp;

            Console.WriteLine("Enter any number:");
            int n = Convert.ToInt32(Console.ReadLine());

            temp = n;

            //  n = 121 = 12

            while(n > 0)
            {
                int r = n % 10; // 121 % 10 = 1, 2, 1
                sum = sum * 10 + r; // 0 * 10 + 1 = 1, 1 * 10 + 2 = 12, 12 * 10 + 1 = 121
                n = n / 10; // 121 / 10 = 12, 1, 0
            }

            n = temp;

            if(sum == n)
            {
                Console.WriteLine("Palindrome Number");
            }
            else
            {
                Console.WriteLine("Not a Palindrome Number");                
            }
        }
    }
}
