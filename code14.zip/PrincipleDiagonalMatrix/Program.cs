﻿using System;

namespace PrincipleDiagonalMatrix
{
    class Program
    {
        static void Main(string[] args)
        {
            int[,] matrix = new int[5, 5];

            Console.WriteLine("Enter number of rows:");
            int rows = Convert.ToInt32(Console.ReadLine());
            
            Console.WriteLine("Enter number of columns:");
            int columns = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter values in Matrix:");
            for(int i = 0; i < rows; i++)
            {
                for(int j = 0; j < columns; j++)
                {
                    matrix[i, j] = Convert.ToInt32(Console.ReadLine());
                }
            }

            Console.WriteLine("Values in Matrix:");
            for(int i = 0; i < rows; i++)
            {
                for(int j = 0; j < columns; j++)
                {
                    Console.Write("{0}\t", matrix[i, j]);
                }
                Console.WriteLine();
            }

            Console.WriteLine("Principle Diagonal Matrix is:");
            for(int i = 0; i < rows; i++)
            {
                for(int j = 0; j < columns; j++)
                {
                    if(i == j)
                    Console.Write("{0}\t", matrix[i, j]);
                }
            }
        }
    }
}
