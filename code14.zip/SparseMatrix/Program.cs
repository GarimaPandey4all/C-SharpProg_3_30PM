﻿using System;

namespace SparseMatrix
{
    class Program
    {
        static void Main(string[] args)
        {
            int[,] matrix = new int[5, 5];

            Console.WriteLine("Enter number of rows:");
            int rows = Convert.ToInt32(Console.ReadLine());
            
            Console.WriteLine("Enter number of columns:");
            int columns = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter values in Matrix:");
            for(int i = 0; i < rows; i++)
            {
                for(int j = 0; j < columns; j++)
                {
                    matrix[i, j] = Convert.ToInt32(Console.ReadLine());
                }
            }

            Console.WriteLine("Values in Matrix:");
            for(int i = 0; i < rows; i++)
            {
                for(int j = 0; j < columns; j++)
                {
                    Console.Write("{0}\t", matrix[i, j]);
                }
                Console.WriteLine();
            }

            int count = 0;
            for(int i = 0; i < rows; i++)
            {
                for(int j = 0; j < columns; j++)
                {
                    if(matrix[i, j] == 0)
                    {
                        count++;
                    }
                }
            }

            if(count > (rows * columns)/2)
            {
                Console.WriteLine("Sparse Matrix");
            }
            else
            {
                Console.WriteLine("Not a Sparse Matrix");
            }
        }
    }
}
