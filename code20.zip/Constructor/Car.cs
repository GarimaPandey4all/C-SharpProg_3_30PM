namespace Constructor
{
    public class Car
    {
        public string model;

        //Default Constructor
        public Car()
        {
            model = "Honda 2020";
        }
    }
}