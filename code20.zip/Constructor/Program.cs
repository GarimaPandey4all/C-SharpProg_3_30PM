﻿using System;

namespace Constructor
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
                Constructor: It is a special type of method/function because the class name and the constructor both are same.
                It is used to initialize objects. It is called when an object of a class is created.            
            */

            Car obj = new Car();

            Console.WriteLine(obj.model);
        }
    }
}
