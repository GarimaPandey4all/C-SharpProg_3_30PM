namespace Constructor_2
{
    public class Car
    {
        public string model;
        public string name;

        //Parameterized Constructor
        public Car(string m, string n)
        {
            model = m;
            name = n;
        }
    }
}