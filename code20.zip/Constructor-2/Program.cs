﻿using System;

namespace Constructor_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Car obj = new Car("Honda 2020", "Honda");

            Console.WriteLine(obj.model);
            Console.WriteLine(obj.name);
        }
    }
}
