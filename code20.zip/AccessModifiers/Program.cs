﻿using System;

namespace AccessModifiers
{
    class Program
    {
        static void Main(string[] args)
        {
            //Access Modifiers: public, private, and protected

            Car obj = new Car("Ford");
            //obj.setData("Ford");
            obj.getData();
        }
    }
}
