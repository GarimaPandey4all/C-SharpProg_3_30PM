using System;

namespace AccessModifiers
{
    public class Car
    {
        private string name;

        // public void setData(string n)
        // {
        //     name = n;
        // }

        public Car(string n)
        {
            name = n;
        }

        public void getData()
        {
            Console.WriteLine(name);
        }
    }
}